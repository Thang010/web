<?php
require_once __DIR__ . "/db.php";
require_once __DIR__ . "/config.php";
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

// Simple auth
function is_logged_in() {
    return isset($_SESSION['auth']) && $_SESSION['auth'] === true;
}

if (isset($_POST['action']) && $_POST['action'] === 'login') {
    $user = $_POST['user'] ?? "";
    $pass = $_POST['pass'] ?? "";
    if ($user === $ADMIN_USER && password_verify($pass, $ADMIN_PASS_HASH)) {
        $_SESSION['auth'] = true;
        header("Location: admin.php");
        exit;
    } else {
        $err = "Sai tài khoản hoặc mật khẩu.";
    }
}

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: admin.php");
    exit;
}

if (!is_logged_in()): ?>
<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body class="bg-dark text-light">
<div class="container py-5">
  <div class="card p-4 mx-auto" style="max-width:420px;background:#111827;border-radius:1rem;border:1px solid #1f2937;">
    <h4 class="mb-3">Đăng nhập Admin</h4>
    <?php if (!empty($err)): ?><div class="alert alert-danger py-2"><?php echo h($err); ?></div><?php endif; ?>
    <form method="post">
      <input type="hidden" name="action" value="login">
      <div class="mb-3">
        <label class="form-label">Tài khoản</label>
        <input class="form-control" name="user" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Mật khẩu</label>
        <input type="password" class="form-control" name="pass" required>
      </div>
      <button class="btn btn-primary w-100">Đăng nhập</button>
    </form>
  </div>
</div>
</body></html>
<?php exit; endif; ?>

<?php
// Actions (approve / delete)
if (isset($_POST['csrf']) && check_csrf($_POST['csrf'])) {
    $db = get_db();
    if (isset($_POST['approve'])) {
        $id = intval($_POST['approve']);
        $db->prepare("UPDATE confessions SET approved=1 WHERE id=:id")->execute([":id"=>$id]);
    }
    if (isset($_POST['delete'])) {
        $id = intval($_POST['delete']);
        // delete image file if exist
        $row = $db->prepare("SELECT image_path FROM confessions WHERE id=:id");
        $row->execute([":id"=>$id]);
        $r = $row->fetch(PDO::FETCH_ASSOC);
        if ($r && !empty($r['image_path'])) {
            $path = __DIR__ . "/uploads/" . $r['image_path'];
            if (is_file($path)) @unlink($path);
        }
        $db->prepare("DELETE FROM confessions WHERE id=:id")->execute([":id"=>$id]);
    }
    header("Location: admin.php");
    exit;
}
?>
<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin · <?php echo h($SITE_NAME); ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
  body { background: #0f172a; color:#e2e8f0; }
  .card { background:#111827; border:1px solid #1f2937; border-radius:1rem; }
  img.conf { max-height: 320px; object-fit: contain; border-radius:.75rem; }
</style>
</head>
<body>
<nav class="navbar navbar-dark bg-dark my-3 mx-2 px-3 rounded-4">
  <span class="navbar-brand mb-0 h1">Admin · <?php echo h($SITE_NAME); ?></span>
  <div class="d-flex gap-2">
    <a href="index.php" class="btn btn-outline-light btn-sm">Trang chủ</a>
    <a href="?logout=1" class="btn btn-outline-light btn-sm">Đăng xuất</a>
  </div>
</nav>

<div class="container mb-5">
  <div class="row g-4">
    <?php
      $db = get_db();
      $tabs = $_GET['tab'] ?? 'pending';
      $where = $tabs === 'approved' ? "approved=1" : "approved=0";
      $stmt = $db->query("SELECT * FROM confessions WHERE $where ORDER BY id DESC");
      $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>
    <ul class="nav nav-pills mb-3">
      <li class="nav-item"><a class="nav-link <?php echo $tabs==='pending'?'active':'';?>" href="?tab=pending">Chờ duyệt</a></li>
      <li class="nav-item"><a class="nav-link <?php echo $tabs==='approved'?'active':'';?>" href="?tab=approved">Đã duyệt</a></li>
    </ul>

    <?php if (!$rows): ?>
      <div class="text-secondary">Không có bản ghi.</div>
    <?php endif; ?>

    <?php foreach ($rows as $r): ?>
      <div class="col-lg-6">
        <div class="card p-3 shadow">
          <div class="d-flex justify-content-between">
            <div>
              <div class="fw-semibold"><?php echo h($r['nickname'] ?: "Ẩn danh"); ?></div>
              <div class="text-secondary small"><?php echo h($r['ip']); ?> · <?php echo h($r['created_at']); ?></div>
            </div>
            <div><span class="badge bg-<?php echo $r['approved']?'success':'warning'; ?>"><?php echo $r['approved']?'ĐÃ DUYỆT':'CHỜ DUYỆT'; ?></span></div>
          </div>
          <p class="mt-2"><?php echo nl2br(h($r['content'])); ?></p>
          <?php if (!empty($r['image_path'])): ?>
            <img class="conf" src="<?php echo 'uploads/' . h($r['image_path']); ?>">
          <?php endif; ?>
          <form method="post" class="mt-3 d-flex gap-2">
            <input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>">
            <?php if (!$r['approved']): ?>
              <button name="approve" value="<?php echo $r['id']; ?>" class="btn btn-success">Duyệt</button>
            <?php endif; ?>
            <button name="delete" value="<?php echo $r['id']; ?>" class="btn btn-danger" onclick="return confirm('Xoá mục này?')">Xoá</button>
          </form>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
</body>
</html>
