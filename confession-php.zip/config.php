<?php
// ===== Basic Config =====
$SITE_NAME = "Confession Box";
$ADMIN_USER = "admin";
// Change this password! You can generate a hash with: password_hash("yourpassword", PASSWORD_DEFAULT)
$ADMIN_PASS_HASH = password_hash("changeme123", PASSWORD_DEFAULT);

// SQLite database file path (stored alongside the app)
$DB_FILE = __DIR__ . "/data.sqlite";

// Max upload size in bytes (e.g., 5MB)
$MAX_UPLOAD_BYTES = 5 * 1024 * 1024;

// Allowed image extensions
$ALLOWED_EXTS = ["jpg","jpeg","png","gif","webp"];

// Base URL (auto-detected). If you host behind reverse proxy, you can hardcode like "https://yourdomain"
$BASE_URL = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") .
            "://".$_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');

// ===== Security headers =====
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
header("Referrer-Policy: no-referrer-when-downgrade");
header("X-XSS-Protection: 1; mode=block");
?>
