<?php
require_once __DIR__ . "/db.php";
require_once __DIR__ . "/config.php";
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
?>
<!doctype html>
<html lang="vi">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo h($SITE_NAME); ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background: #0f172a; color: #e2e8f0; }
    .navbar, .card { border-radius: 1rem; }
    .card { background: #111827; border: 1px solid #1f2937; }
    .form-control, .form-select { background: #0b1220; color:#e2e8f0; border-color:#243144; }
    .form-control:focus { border-color:#60a5fa; box-shadow: none; }
    .btn-primary { background:#2563eb; border:none; }
    .badge-status { font-size: .75rem; }
    footer { color:#94a3b8; }
    a { color: #93c5fd; }
    img.conf { max-height: 420px; object-fit: contain; border-radius: .75rem; }
  </style>
</head>
<body>
<nav class="navbar navbar-dark bg-dark my-3 mx-2 px-3 rounded-4">
  <span class="navbar-brand mb-0 h1"><?php echo h($SITE_NAME); ?></span>
  <a class="btn btn-outline-light btn-sm" href="admin.php">Admin</a>
</nav>

<div class="container mb-5">
  <div class="row g-4">
    <div class="col-lg-5">
      <div class="card p-4 shadow">
        <h5 class="mb-3">Gửi Confession ẩn danh</h5>
        <form method="post" action="submit.php" enctype="multipart/form-data">
          <input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>">
          <div class="mb-3">
            <label class="form-label">Nickname (tuỳ chọn)</label>
            <input name="nickname" maxlength="40" class="form-control" placeholder="Ví dụ: 'Một chiếc lá'">
          </div>
          <div class="mb-3">
            <label class="form-label">Nội dung *</label>
            <textarea name="content" class="form-control" rows="5" maxlength="2000" required placeholder="Viết điều bạn muốn tâm sự..."></textarea>
            <div class="form-text text-secondary">Tối đa 2000 ký tự. Nội dung sẽ chờ duyệt.</div>
          </div>
          <div class="mb-3">
            <label class="form-label">Ảnh đính kèm (tuỳ chọn)</label>
            <input type="file" name="image" accept="image/*" class="form-control">
            <div class="form-text text-secondary">Dung lượng ≤ 5MB. Cho phép: jpg, png, gif, webp.</div>
          </div>
          <button class="btn btn-primary w-100">Gửi confession</button>
        </form>
      </div>
    </div>
    <div class="col-lg-7">
      <h5 class="mb-3">✨ Confession mới nhất</h5>
      <?php
        $db = get_db();
        // Pagination
        $page = max(1, intval($_GET['page'] ?? 1));
        $per = 8;
        $offset = ($page - 1) * $per;

        $total = $db->query("SELECT COUNT(*) FROM confessions WHERE approved=1")->fetchColumn();
        $stmt = $db->prepare("SELECT * FROM confessions WHERE approved=1 ORDER BY id DESC LIMIT :per OFFSET :off");
        $stmt->bindValue(":per", $per, PDO::PARAM_INT);
        $stmt->bindValue(":off", $offset, PDO::PARAM_INT);
        $stmt->execute();
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if (!$rows) {
          echo '<div class="text-secondary">Chưa có bài nào được duyệt.</div>';
        }
        foreach ($rows as $r):
      ?>
      <div class="card mb-3 p-3 shadow">
        <div class="d-flex justify-content-between align-items-center">
          <div class="fw-semibold"><?php echo h($r['nickname'] ?: "Ẩn danh"); ?></div>
          <div class="badge bg-secondary-subtle text-secondary-emphasis badge-status">
            <?php echo h(date("H:i d/m/Y", strtotime($r['created_at']))); ?>
          </div>
        </div>
        <p class="mt-2"><?php echo nl2br(h($r['content'])); ?></p>
        <?php if (!empty($r['image_path'])): ?>
          <img class="conf mt-2" src="<?php echo 'uploads/' . h($r['image_path']); ?>" alt="confession image">
        <?php endif; ?>
      </div>
      <?php endforeach; ?>

      <?php if ($total > $per): 
        $pages = ceil($total / $per); ?>
        <nav>
          <ul class="pagination mt-3">
            <?php for ($i=1; $i<=$pages; $i++): ?>
              <li class="page-item <?php echo $i==$page?'active':''; ?>">
                <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
              </li>
            <?php endfor; ?>
          </ul>
        </nav>
      <?php endif; ?>
    </div>
  </div>
</div>
<footer class="text-center pb-5">
  <small>© <?php echo date('Y'); ?> · Powered by PHP + SQLite</small>
</footer>
</body>
</html>
