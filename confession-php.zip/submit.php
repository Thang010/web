<?php
require_once __DIR__ . "/db.php";
require_once __DIR__ . "/config.php";
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !check_csrf($_POST['csrf'] ?? "")) {
    http_response_code(400);
    echo "Invalid request.";
    exit;
}

$nickname = trim($_POST['nickname'] ?? "");
$content  = trim($_POST['content'] ?? "");

if ($content === "" || mb_strlen($content) > 2000) {
    $_SESSION['flash'] = "Nội dung không hợp lệ.";
    header("Location: index.php");
    exit;
}

$image_name = null;
if (!empty($_FILES['image']['name'])) {
    global $ALLOWED_EXTS, $MAX_UPLOAD_BYTES;
    if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        $_SESSION['flash'] = "Upload ảnh lỗi.";
        header("Location: index.php");
        exit;
    }
    if ($_FILES['image']['size'] > $MAX_UPLOAD_BYTES) {
        $_SESSION['flash'] = "Ảnh vượt quá dung lượng cho phép.";
        header("Location: index.php");
        exit;
    }
    $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $ALLOWED_EXTS)) {
        $_SESSION['flash'] = "Định dạng ảnh không được phép.";
        header("Location: index.php");
        exit;
    }
    $safeBase = bin2hex(random_bytes(8));
    $image_name = $safeBase . "." . $ext;
    $dest = __DIR__ . "/uploads/" . $image_name;
    if (!move_uploaded_file($_FILES['image']['tmp_name'], $dest)) {
        $_SESSION['flash'] = "Không lưu được ảnh.";
        header("Location: index.php");
        exit;
    }
}

$ip = $_SERVER['REMOTE_ADDR'] ?? null;
$db = get_db();
$stmt = $db->prepare("INSERT INTO confessions (content, nickname, image_path, ip, approved) VALUES (:c, :n, :i, :ip, 0)");
$stmt->execute([":c"=>$content, ":n"=>$nickname ?: null, ":i"=>$image_name, ":ip"=>$ip]);

// Simple thank-you page
?>
<!doctype html>
<html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Đã gửi</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body class="bg-dark text-light">
<div class="container py-5">
  <div class="card p-4 mx-auto" style="max-width:600px;background:#111827;border-radius:1rem;border:1px solid #1f2937;">
    <h4>Cảm ơn bạn!</h4>
    <p>Confession đã được gửi và sẽ hiển thị sau khi quản trị viên duyệt.</p>
    <a class="btn btn-primary" href="index.php">Quay lại trang chủ</a>
  </div>
</div>
</body></html>
